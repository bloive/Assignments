package com.example.cattr

class User (val name: String, var email: String) {}